from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

dbInfo = "mysql+mysqldb://root:Animusic1574@ani.cr3ngl9ucixu.ap-northeast-2.rds.amazonaws.com:3306/Animusic"
engine = create_engine(dbInfo, echo=True)
Session = sessionmaker(engine)
session = Session()

Base = declarative_base()